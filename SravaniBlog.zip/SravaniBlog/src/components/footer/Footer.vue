<template>
  <v-footer dark>
    <v-row>
      <v-col align="center">
        <span class="ma-5"> Contact : {{ info.mobile }}</span>
        <span class="ma-5"> LinkedIn : {{ info.linkedIn }}</span>
        <span class="ma-5"> Email Id: {{ info.mail }}</span>
      </v-col>
    </v-row>
  </v-footer>
</template>

<script>
import { info } from "@/views/sravani-detail.js";
export default {
  name: "AppFooter",
  data() {
    return {
      info: info
    };
  }
};
</script>
