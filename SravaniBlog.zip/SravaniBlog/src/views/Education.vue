<template>
  <div>
    <v-container fluid>
      <v-row>
        <h1 class="ma-3">Education :</h1>
      </v-row>
      <v-row>
        <v-flex
          md12
          sm12
          v-for="(studies, index) in info.education"
          :key="index"
        >
          <v-row
            ><h2 class="ma-5">{{ studies.name }}</h2></v-row
          >
          <v-row
            ><span class="ma-5">{{ studies.content }}</span></v-row
          >
        </v-flex>
      </v-row>
      <v-row>
        <h1 class="ma-3">Certifications :</h1>
      </v-row>
      <v-row>
        <v-flex
          md12
          sm12
          v-for="(certificate, index) in info.certifications"
          :key="index"
        >
          <span class="ma-5">{{ certificate }}</span>
        </v-flex>
      </v-row>
    </v-container>
  </div>
</template>

<script>
// @ is an alias to /src
import { info } from "@/views/sravani-detail.js";
export default {
  name: "Education",
  data() {
    return {
      info: info
    };
  }
};
</script>
