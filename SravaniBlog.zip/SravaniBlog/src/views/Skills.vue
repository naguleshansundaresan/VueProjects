<template>
  <div>
    <v-container>
      <v-row>
        <h1>Skills :</h1>
      </v-row>
      <v-row>
        <v-simple-table dark>
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-left">Skill</th>
                <th class="text-left">Content</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(skill, index) in info.skills" :key="index">
                <td>{{ skill.name }}</td>
                <td>{{ skill.content }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-row>
    </v-container>
  </div>
</template>

<script>
// @ is an alias to /src
import { info } from "@/views/sravani-detail.js";
export default {
  name: "Skills",
  data() {
    return {
      info: info
    };
  }
};
</script>
