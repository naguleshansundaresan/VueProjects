export const info = {
  name: "Sravani",
  dob: "17/09/1997",
  role: "Cloud Associate",
  company: "Amazon",
  intro:
    "Hi, My name is Sravani. I'm a Cloud Associate from Amazon. I am a very enthusiastic and goal-oriented person who is working hard and giving full support to the company",
  native: "Chennai",
  workingLocation: "Bangalore",
  mobile: "+91 8870924319",
  linkedIn: "www.linkedin.com/in/sravani-shivakumar-760ab7135/",
  mail: "sravanishivkumar17@gmail.com",
  skills: [
    {
      name: "Hardware",
      content: "Cisco Catalyst Switch 2960, Cisco Routers 2611"
    },
    { name: "Programming", content: "JAVA" },
    {
      name: "RoutingProtocols",
      content: "RIP, OSPF, EIGRP, BGP, Route redistribution"
    },
    { name: "Switching", content: "VLAN, STP, RSTP Wan" },
    { name: "Technology", content: "HDLC, PPP, Frame Relay And MPLS." },
    {
      name: "Security",
      content: "ACL, NAT, Port Security, Penetration Testing, IDS."
    },
    {
      name: "OperatingSystems",
      content:
        "Windows, Linux. VPN Technologies : Site-to-Site VPN, Remote Access VPN."
    },
    { name: "InfrastructureService", content: "DHCP, FTP, DNS, ICMP." },
    {
      name: "Wireless",
      content: "802.11 a/b/g/n/s/e, MANETs, WEP, WPA, WPA2."
    },
    { name: "NETWORKMANAGEMENT", content: "Cisco Networks LAN, TCP dump." }
  ],
  education: [
    {
      name: "College",
      content:
        "Bachelor of Technology in Information Technology MAY 2019 Sastra Deemed University (GPA: 6.79/10) "
    },
    {
      name: "School",
      content:
        "Pre University MAY 2015 Zion Matriculation Higher Secondary School (GPA: 9.5/10)"
    }
  ],
  certifications: [
    "Comptia Security Plus SYS 401",
    "AWS Certified Solutions Architect - Associate",
    "AWS Certified Solutions Architect - Professional"
  ],
  internship: `INTERNSHIP INTERN | DIGITAL TRACK SOLUTIONS | JUN 2018 – JUL 2018 | NETWORK SECURITY 
        • Hands on experience on Fortinet Firewall 100E series 
        • Completed a project on configuring FORTINET FIREWALL for client Infrastructure with SSL, VPN, LLB and basic filters INTERN|HEWLETT PACKARD|DEC 2016-JAN 2017 | NETWORKING 
        • Hands on experience on Cisco Routers 2611 
        • Hands on experience on Cisco Catalyst Switch 2960 
        `,
  areaOfInterest: [
    { name: "Networking", rating: 89 },
    { name: "Network Security", rating: 91 },
    { name: "AWS Cloud", rating: 94 }
  ],
  workshop:
    "Conducted workshop on Web Application penetration testing which involves SQL injection, Cross site scripting, Broken session management, Improper server side validation, Weak implementation of business logic. "
};
