<template>
  <div class="home">
    <v-container fluid>
      <v-row>
        <v-flex md6 sm3>
          <v-img
            class="ma-10"
            src="../../src/assets/sravani.jpg"
            max-height="500"
            max-width="600"
          ></v-img>
        </v-flex>
        <v-flex md6 sm3>
          <h2 class="my-15 ml-5 mr-15">{{ info.intro }}</h2>
          <h2 class="ma-5">Interest</h2>
          <v-flex
            md6
            sm6
            class="ma-5"
            v-for="interest in info.areaOfInterest"
            :key="interest.rating"
          >
            <v-progress-circular :value="interest.rating">{{
              interest.rating
            }}</v-progress-circular
            ><span class="ma-5">{{ interest.name }}</span>
          </v-flex>
        </v-flex>
      </v-row>
    </v-container>
  </div>
</template>

<script>
// @ is an alias to /src
import { info } from "@/views/sravani-detail.js";
export default {
  name: "Home",
  data() {
    return {
      info: info
    };
  }
};
</script>
