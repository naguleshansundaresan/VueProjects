<template>
  <v-app style="background-color:lightgrey">
    <AppHeader></AppHeader>
    <v-content>
      <router-view />
    </v-content>
    <footer>
      <AppFooter></AppFooter>
    </footer>
  </v-app>
</template>

<script>
import AppHeader from "@/components/header/Header.vue";
import AppFooter from "@/components/footer/Footer.vue";
export default {
  name: "App",
  components: {
    AppHeader,
    AppFooter
  }
};
</script>
